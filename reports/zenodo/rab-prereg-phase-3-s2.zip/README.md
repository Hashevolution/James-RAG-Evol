# RAB Phase 3 (scenario-S2) Pre-Registration — Zenodo Deposit

This zip packages the **locked** pre-registration of the
Replayable-Audit Benchmark (RAB) Phase 3 measurement
(scenario-S2 'lifecycle-large'), to be deposited on Zenodo as
a separate citable record from the v0.4.3 software archive.

## Contents

- `r1-phase-3-scenario-s2-preregistration-2026-06-10.md` —
  the pre-registration document, locked at commit
  `d21c680a51ba455f6712cca21db38af310b5868f` (PR #774, 2026-06-10).
- `RAB-SPEC-v0.1.md` — the SPEC v0.1.1 the pre-registration
  commits to test (frozen 2026-06-10).
- `build_rab_prereg_deposit.py` — the script that produced
  this bundle (reproducibility witness).

## Verification

Anyone can independently verify this bundle by running
`git show d21c680a51ba455f6712cca21db38af310b5868f` against the source repository
(`Hashevolution/James-RAG-Evol`). The commit predates the
scenario-S2 fixture file (added in a later commit).

## Related identifiers

- RAB software archive at locking time: DOI
  10.5281/zenodo.20625533 (v0.4.3, 2026-06-10).
- Locking commit: GitHub `d21c680a51ba455f6712cca21db38af310b5868f` (PR #774).

## Purpose

The locking commit hash is the in-git priority evidence;
this Zenodo deposit is the external timestamped anchor.
Any RAB scenario-S2 result that cites this DOI must report
spec version, scenario sha, and re-verification artifacts
per RAB SPEC v0.1.1 §4.
